
# BioSync/dna_generator.py

import random

def generate_dna_sequence(length):
    """
    Generates a random DNA sequence of a given length.
    DNA bases: A, T, C, G
    """
    if not isinstance(length, int) or length <= 0:
        print("Error: Length must be a positive integer.")
        return ""
    
    bases = ['A', 'T', 'C', 'G']
    return ''.join(random.choice(bases) for _ in range(length))

# Example usage (for testing this module directly, if needed)
if __name__ == "__main__":
    print("Generating a 10 bp DNA sequence:", generate_dna_sequence(10))
    print("Generating a 50 bp DNA sequence:", generate_dna_sequence(50))
    print("Generating with invalid length:", generate_dna_sequence(0))
