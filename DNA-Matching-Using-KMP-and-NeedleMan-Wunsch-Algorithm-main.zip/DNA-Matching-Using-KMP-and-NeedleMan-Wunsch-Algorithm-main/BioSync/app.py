# BioSync/app.py

from flask import Flask, render_template, request, jsonify
import sys
import os

# Add the parent directory of BioSync to the Python path
# This is crucial for Flask to find the BioSync package and its modules
# when running `flask run` or similar commands from the project root.
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

# Import functions from the other modules within the BioSync package
from BioSync.dna_generator import generate_dna_sequence
from BioSync.kmp_matcher import kmp_search
from BioSync.needleman_wunsch import needleman_wunsch_align

app = Flask(__name__, template_folder=os.path.join(parent_dir, 'templates'))

# Global storage for DNA sequences. In a real multi-user app,
# you'd use session management or a database.
generated_dna_sequences = {
    "seq1": "",
    "seq2": ""
}

@app.route('/')
def index():
    """Renders the main index.html page."""
    return render_template('index.html')

@app.route('/generate_dna', methods=['POST'])
def generate_dna():
    """
    Generates two random DNA sequences based on user-provided lengths.
    Stores them globally and returns them as JSON.
    """
    data = request.get_json()
    try:
        length1 = int(data.get('length1', 0))
        length2 = int(data.get('length2', 0))

        if length1 <= 0 or length2 <= 0:
            return jsonify({"error": "Lengths must be positive integers."}), 400

        seq1 = generate_dna_sequence(length1)
        seq2 = generate_dna_sequence(length2)

        generated_dna_sequences["seq1"] = seq1
        generated_dna_sequences["seq2"] = seq2

        return jsonify({
            "success": True,
            "seq1": seq1,
            "seq2": seq2,
            "message": "DNA sequences generated successfully!"
        })
    except ValueError:
        return jsonify({"error": "Invalid length provided. Please enter integers."}), 400
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@app.route('/perform_kmp', methods=['POST'])
def perform_kmp():
    """
    Performs KMP search on a selected DNA sequence with a given pattern.
    Returns matches and a highlighted text version.
    """
    data = request.get_json()
    dna_choice = data.get('dnaChoice') # 'seq1' or 'seq2'
    pattern = data.get('pattern', '').upper()

    text_to_search = generated_dna_sequences.get(dna_choice)

    if not text_to_search:
        return jsonify({"error": f"No DNA sequence '{dna_choice}' generated yet. Please generate DNA first."}), 400
    if not pattern:
        return jsonify({"error": "Please provide a pattern to search."}), 400
    if not all(base in 'ATCG' for base in pattern):
        return jsonify({"error": "Invalid pattern. Use only A, T, C, G."}), 400

    matches = kmp_search(text_to_search, pattern)

    # Prepare highlighted text for display in HTML
    highlighted_text = list(text_to_search)
    for start_idx in matches:
        for k in range(len(pattern)):
            # Using a placeholder for highlighting; JS will render this.
            # We'll wrap it in a custom tag or class for JS to find.
            highlighted_text[start_idx + k] = f"<span class='kmp-highlight'>{highlighted_text[start_idx + k]}</span>"
    
    # Reconstruct the string, but ensure it's HTML safe (e.g., using Markup in Jinja if rendering directly)
    # For jsonify, we'll just send the raw string and let JS handle HTML insertion.
    final_highlighted_text = ''.join(highlighted_text)


    return jsonify({
        "success": True,
        "matches": matches,
        "highlightedText": final_highlighted_text,
        "originalTextLength": len(text_to_search)
    })

@app.route('/perform_nw', methods=['POST'])
def perform_nw():
    """
    Performs Needleman-Wunsch global alignment between the two generated DNA sequences.
    Returns alignment score, aligned sequences, and the scoring matrix.
    """
    data = request.get_json()
    try:
        match_score = int(data.get('matchScore', 2))
        mismatch_penalty = int(data.get('mismatchPenalty', -1))
        gap_penalty = int(data.get('gapPenalty', -2))
    except ValueError:
        return jsonify({"error": "Invalid score/penalty. Please enter integers."}), 400

    seq1 = generated_dna_sequences.get("seq1")
    seq2 = generated_dna_sequences.get("seq2")

    if not seq1 or not seq2:
        return jsonify({"error": "Please generate two DNA sequences first (Option 1)."})

    score, aligned_s1, aligned_s2, matrix = needleman_wunsch_align(
        seq1, seq2, match_score=match_score, mismatch_penalty=mismatch_penalty, gap_penalty=gap_penalty
    )

    # Convert matrix to a list of lists for JSON serialization
    matrix_serializable = [list(row) for row in matrix]

    return jsonify({
        "success": True,
        "score": score,
        "alignedSeq1": aligned_s1,
        "alignedSeq2": aligned_s2,
        "matrix": matrix_serializable
    })

if __name__ == '__main__':
    # When running directly, ensure the path is set up for imports
    # This block is mostly for development convenience.
    # For production, `flask run` from the project root is preferred.
    app.run(debug=True)
