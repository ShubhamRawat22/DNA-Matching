# BioSync/main.py

import sys
import os

# Use relative imports for modules within the same package/directory
# This is the standard way to import when running as a module (python -m BioSync.main)
from .dna_generator import generate_dna_sequence
from .kmp_matcher import kmp_search
from .needleman_wunsch import needleman_wunsch_align

def print_kmp_results(text, pattern, matches):
    """Prints KMP search results with highlighted matches."""
    print(f"\n--- KMP Search Results ---")
    print(f"Text:    {text}")
    print(f"Pattern: {pattern}")
    
    if matches:
        print(f"Pattern found at indices: {matches}")
        highlighted_text = list(text)
        for start_idx in matches:
            for k in range(len(pattern)):
                # Using ANSI escape codes for green color (might not work in all terminals)
                highlighted_text[start_idx + k] = f"\033[92m{highlighted_text[start_idx + k]}\033[0m"
        print(f"Highlighted Text: {''.join(highlighted_text)}")
    else:
        print("Pattern not found in the text.")
    print("--------------------------")

def print_needleman_wunsch_results(score, aligned_seq1, aligned_seq2, seq1_orig, seq2_orig, matrix):
    """Prints Needleman-Wunsch alignment results with visual representation."""
    print(f"\n--- Needleman-Wunsch Global Alignment Results ---")
    print(f"Original Sequence 1: {seq1_orig}")
    print(f"Original Sequence 2: {seq2_orig}")
    print(f"Alignment Score: {score}")
    print("\nOptimal Alignment:")
    print(f"Seq1: {aligned_seq1}")
    print(f"      {''.join(['|' if s1 == s2 and s1 != '-' else ' ' for s1, s2 in zip(aligned_seq1, aligned_seq2)])}")
    print(f"Seq2: {aligned_seq2}")

    print("\nScoring Matrix (F):")
    # Print header row for seq2
    print("      " + " ".join([f"{base:2}" for base in ['-'] + list(seq2_orig)]))
    for i, row in enumerate(matrix):
        # Print header column for seq1
        row_header = '-' if i == 0 else seq1_orig[i-1]
        print(f"{row_header:2} | " + " ".join([f"{val:2}" for val in row]))
    print("--------------------------------------------------")

def main_menu():
    """Displays the main menu and handles user choices."""
    dna_seq1 = ""
    dna_seq2 = ""
    
    print("Welcome to BioSync: A DNA Matching Explorer!")
    print("----------------------------------------------")

    while True:
        print("\nMain Menu:")
        print("1. Generate Random DNA Sequences")
        print("2. Perform KMP Search (Exact Marker Matching)")
        print("3. Perform Needleman-Wunsch Alignment (Ancestry/Similarity Matching)")
        print("4. Exit")

        choice = input("Enter your choice (1-4): ")

        if choice == '1':
            try:
                len1 = int(input("Enter length for DNA Sequence 1: "))
                dna_seq1 = generate_dna_sequence(len1)
                print(f"Generated DNA Sequence 1 ({len(dna_seq1)} bp): {dna_seq1}")
                
                len2 = int(input("Enter length for DNA Sequence 2: "))
                dna_seq2 = generate_dna_sequence(len2)
                print(f"Generated DNA Sequence 2 ({len(dna_seq2)} bp): {dna_seq2}")
            except ValueError:
                print("Invalid input. Please enter an integer for length.")
        
        elif choice == '2':
            if not dna_seq1:
                print("Please generate DNA sequences first (Option 1).")
                continue
            
            pattern = input("Enter the DNA pattern to search for (e.g., ATGC): ").upper()
            if not all(base in 'ATCG' for base in pattern):
                print("Invalid pattern. Please use only A, T, C, G.")
                continue

            matches = kmp_search(dna_seq1, pattern)
            print_kmp_results(dna_seq1, pattern, matches)
            
            # Optional: search in seq2 as well
            if dna_seq2:
                matches_seq2 = kmp_search(dna_seq2, pattern)
                print_kmp_results(dna_seq2, pattern, matches_seq2)

        elif choice == '3':
            if not dna_seq1 or not dna_seq2:
                print("Please generate two DNA sequences first (Option 1).")
                continue
            
            print("\n--- Needleman-Wunsch Parameters (default scores: match=2, mismatch=-1, gap=-2) ---")
            try:
                match_s = int(input("Enter match score (default 2): ") or 2)
                mismatch_p = int(input("Enter mismatch penalty (default -1): ") or -1)
                gap_p = int(input("Enter gap penalty (default -2): ") or -2)
            except ValueError:
                print("Invalid input for scores. Using default values.")
                match_s, mismatch_p, gap_p = 2, -1, -2

            score, aligned_s1, aligned_s2, matrix = needleman_wunsch_align(
                dna_seq1, dna_seq2, match_score=match_s, mismatch_penalty=mismatch_p, gap_penalty=gap_p
            )
            print_needleman_wunsch_results(score, aligned_s1, aligned_s2, dna_seq1, dna_seq2, matrix)

        elif choice == '4':
            print("Exiting BioSync. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a number between 1 and 4.")

if __name__ == "__main__":
    main_menu()