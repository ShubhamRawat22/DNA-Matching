 const generateDnaBtn = document.getElementById('generateDnaBtn');
        const length1Input = document.getElementById('length1');
        const length2Input = document.getElementById('length2');
        const dnaSeq1Display = document.getElementById('dnaSeq1Display');
        const dnaSeq2Display = document.getElementById('dnaSeq2Display');
        const generationMessage = document.getElementById('generationMessage');
        const generateSpinner = document.getElementById('generateSpinner');

        const performKmpBtn = document.getElementById('performKmpBtn');
        const kmpPatternInput = document.getElementById('kmpPattern');
        const kmpDnaChoice = document.getElementById('kmpDnaChoice');
        const kmpResultDisplay = document.getElementById('kmpResultDisplay');
        const kmpMatchesIndices = document.getElementById('kmpMatchesIndices');
        const kmpMessage = document.getElementById('kmpMessage');
        const kmpSpinner = document.getElementById('kmpSpinner');

        const performNwBtn = document.getElementById('performNwBtn');
        const nwSeq1Input = document.getElementById('nwSeq1Input'); 
        const nwSeq2Input = document.getElementById('nwSeq2Input'); 
        const matchScoreInput = document.getElementById('matchScore');
        const mismatchPenaltyInput = document.getElementById('mismatchPenalty');
        const gapPenaltyInput = document.getElementById('gapPenalty');
        const nwScoreDisplay = document.getElementById('nwScore');
        const nwAlignmentDisplay = document.getElementById('nwAlignmentDisplay');
        const nwMatrixDisplay = document.getElementById('nwMatrixDisplay');
        const nwMessage = document.getElementById('nwMessage');
        const nwSpinner = document.getElementById('nwSpinner');

        
        const dashboardSeq1Length = document.getElementById('dashboardSeq1Length');
        const dashboardSeq2Length = document.getElementById('dashboardSeq2Length');
        const dashboardKmpPattern = document.getElementById('dashboardKmpPattern');
        const dashboardKmpMatches = document.getElementById('dashboardKmpMatches');
        const dashboardNwScore = document.getElementById('dashboardNwScore');
        const dashboardNwSimilarity = document.getElementById('dashboardNwSimilarity');

        
        const scanDiseaseMarkersBtn = document.getElementById('scanDiseaseMarkersBtn');
        const diseaseScanResults = document.getElementById('diseaseScanResults');
        const diseaseSpinner = document.getElementById('diseaseSpinner');

        
        const navItems = document.querySelectorAll('.nav-item');
        const contentSections = document.querySelectorAll('.content-section');
        const welcomeSection = document.getElementById('welcome-section');
        const getStartedBtn = document.getElementById('getStartedBtn');

        
        const allSections = [
            'welcome-section', 
            'dashboard-section',
            'generate-dna-section',
            'kmp-section',
            'nw-section',
            'login-section',
            'profile-section'
        ];
        let currentSectionIndex = 0; 

        
        const diseaseMarkers = [
            { name: "Marker for Hypothetical Condition A", sequence: "ATGCGTACGT", risk: "High" },
            { name: "Marker for Hypothetical Condition B", sequence: "GGATCCAG", risk: "Medium" },
            { name: "Marker for Hypothetical Condition C", sequence: "CCTAGGT", risk: "Low" },
            { name: "Marker for Hypothetical Condition D", sequence: "TCGATCG", risk: "High" },
            { name: "Marker for Hypothetical Condition E", sequence: "AGAGAGAG", risk: "Medium" }
        ];


        
        function toggleSpinner(spinnerElement, show) {
            if (show) {
                spinnerElement.classList.remove('hidden');
            } else {
                spinnerElement.classList.add('hidden');
            }
        }

        
        function updateDashboard(type, data = {}) {
            if (type === 'dna') {
                dashboardSeq1Length.textContent = data.seq1Length || 'N/A';
                dashboardSeq2Length.textContent = data.seq2Length || 'N/A';
                
                dashboardKmpPattern.textContent = 'N/A';
                dashboardKmpMatches.textContent = 'N/A';
                dashboardNwScore.textContent = 'N/A';
                dashboardNwSimilarity.textContent = 'N/A';
                diseaseScanResults.innerHTML = ''; 
            } else if (type === 'kmp') {
                dashboardKmpPattern.textContent = data.pattern || 'N/A';
                dashboardKmpMatches.textContent = data.matchesCount !== undefined ? data.matchesCount : 'N/A';
            } else if (type === 'nw') {
                dashboardNwScore.textContent = data.score !== undefined ? data.score : 'N/A';



                dashboardNwSimilarity.textContent = data.similarity !== undefined ? `${data.similarity}%` : 'N/A';
                
                const seq1Len = nwSeq1Input.value.length; 
                const seq2Len = nwSeq2Input.value.length;
                if (seq1Len > 0 && seq2Len > 0) {
                    const maxPossibleScore = Math.min(seq1Len, seq2Len) * parseInt(matchScoreInput.value);
                    const similarity = (data.score / maxPossibleScore * 100).toFixed(2);
                    dashboardNwSimilarity.textContent = `${similarity}%`;
                } else {
                    dashboardNwSimilarity.textContent = 'N/A';
                }
            }
        }




        
        function showSection(sectionId) {
            
            contentSections.forEach(section => section.classList.add('hidden'));

            
            const targetSection = document.getElementById(sectionId);
            if (targetSection) {
                targetSection.classList.remove('hidden');
            }

            
            navItems.forEach(nav => nav.classList.remove('active-nav-item'));

            
            if (sectionId !== 'welcome-section') {
                const activeNavItem = document.querySelector(`.nav-item[data-section="${sectionId}"]`);
                if (activeNavItem) {
                    activeNavItem.classList.add('active-nav-item');
                }
            }
            currentSectionIndex = allSections.indexOf(sectionId); 
        }


        


  








        
        generateDnaBtn.addEventListener('click', async () => {
            generationMessage.textContent = '';
            toggleSpinner(generateSpinner, true);
            try {
                const response = await fetch('/generate_dna', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        length1: parseInt(length1Input.value),
                        length2: parseInt(length2Input.value)
                    })
                });
                const result = await response.json();

                if (result.success) {
                    dnaSeq1Display.value = result.seq1;
                    dnaSeq2Display.value = result.seq2;
                    generationMessage.textContent = result.message;
                    generationMessage.classList.remove('text-red-500');
                    generationMessage.classList.add('text-green-600');
                    updateDashboard('dna', { seq1Length: result.seq1.length, seq2Length: result.seq2.length });
                } else {
                    generationMessage.textContent = `Error: ${result.error}`;
                    generationMessage.classList.remove('text-green-600');
                    generationMessage.classList.add('text-red-500');
                }
            } catch (error) {
                generationMessage.textContent = `Network error: ${error.message}`;
                generationMessage.classList.remove('text-green-600');
                generationMessage.classList.add('text-red-500');
            } finally {
                toggleSpinner(generateSpinner, false);
            }
        });

        
        performKmpBtn.addEventListener('click', async () => {
            kmpMessage.textContent = '';
            kmpResultDisplay.innerHTML = ''; 
            kmpMatchesIndices.textContent = '';
            toggleSpinner(kmpSpinner, true);

            try {
                const response = await fetch('/perform_kmp', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        dnaChoice: kmpDnaChoice.value,
                        pattern: kmpPatternInput.value
                    })
                });
                const result = await response.json();

                if (result.success) {
                    kmpResultDisplay.innerHTML = result.highlightedText;
                    kmpMatchesIndices.textContent = `Pattern found at indices: ${result.matches.join(', ')} (Total length: ${result.originalTextLength} bp)`;
                    kmpMessage.textContent = "KMP search completed successfully!";
                    kmpMessage.classList.remove('text-red-500');
                    kmpMessage.classList.add('text-green-600');
                    updateDashboard('kmp', { pattern: kmpPatternInput.value, matchesCount: result.matches.length });
                } else {
                    kmpMessage.textContent = `Error: ${result.error}`;
                    kmpMessage.classList.remove('text-green-600');
                    kmpMessage.classList.add('text-red-500');
                }
            } catch (error) {
                kmpMessage.textContent = `Network error: ${error.message}`;
                kmpMessage.classList.remove('text-green-600');
                kmpMessage.classList.add('text-red-500');
            } finally {
                toggleSpinner(kmpSpinner, false);
            }
        });

        
        performNwBtn.addEventListener('click', async () => {
            nwMessage.textContent = '';
            nwScoreDisplay.textContent = '';
            nwAlignmentDisplay.innerHTML = '';
            nwMatrixDisplay.innerHTML = ''; 
            toggleSpinner(nwSpinner, true);

            try {
                const response = await fetch('/perform_nw', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        seq1: nwSeq1Input.value, 
                        seq2: nwSeq2Input.value, 
                        matchScore: parseInt(matchScoreInput.value),
                        mismatchPenalty: parseInt(mismatchPenaltyInput.value),
                        gapPenalty: parseInt(gapPenaltyInput.value)
                    })
                });
                const result = await response.json();

                if (result.success) {
                    nwScoreDisplay.textContent = `Alignment Score: ${result.score}`;
                    nwAlignmentDisplay.innerHTML = `
                        <div>Seq1: ${result.alignedSeq1}</div>
                        <div>      ${result.alignedSeq1.split('').map((s1, i) => s1 === result.alignedSeq2[i] && s1 !== '-' ? '|' : ' ').join('')}</div>
                        <div>Seq2: ${result.alignedSeq2}</div>
                    `;

                    
                    let matrixHtml = '<table class="nw-matrix-table">';
                    
                    matrixHtml += '<thead><tr><th></th>';
                    matrixHtml += '<th>-</th>'; 
                    const seq2_orig_nw = nwSeq2Input.value; 
                    for (const base of seq2_orig_nw) {
                        matrixHtml += `<th>${base}</th>`;
                    }
                    matrixHtml += '</tr></thead><tbody>';

                    
                    const seq1_orig_nw = nwSeq1Input.value; 
                    for (let i = 0; i < result.matrix.length; i++) {
                        matrixHtml += '<tr>';
                        
                        matrixHtml += `<th>${i === 0 ? '-' : seq1_orig_nw[i-1]}</th>`;
                        for (let j = 0; j < result.matrix[i].length; j++) {
                            matrixHtml += `<td>${result.matrix[i][j]}</td>`;
                        }
                        matrixHtml += '</tr>';
                    }
                    matrixHtml += '</tbody></table>';
                    nwMatrixDisplay.innerHTML = matrixHtml;

                    nwMessage.textContent = "Needleman-Wunsch alignment completed successfully!";
                    nwMessage.classList.remove('text-red-500');
                    nwMessage.classList.add('text-green-600');
                    updateDashboard('nw', { score: result.score });

                } else {
                    nwMessage.textContent = `Error: ${result.error}`;
                    nwMessage.classList.remove('text-green-600');
                    nwMessage.classList.add('text-red-500');
                }
            } catch (error) {
                nwMessage.textContent = `Network error: ${error.message}`;
                nwMessage.classList.remove('text-green-600');
                nwMessage.classList.add('text-red-500');
            } finally {
                toggleSpinner(nwSpinner, false);
            }
        });

 














        
        scanDiseaseMarkersBtn.addEventListener('click', async () => {
            diseaseScanResults.innerHTML = ''; 
            toggleSpinner(diseaseSpinner, true);

            const dnaSeq1 = dnaSeq1Display.value; 
            if (!dnaSeq1) {
                diseaseScanResults.innerHTML = '<p class="text-red-500">Please generate DNA Sequence 1 first in the "Generate DNA Sequences" section.</p>';
                toggleSpinner(diseaseSpinner, false);
                return;
            }

            let resultsHtml = '<h4 class="text-lg font-medium mb-2">Scan Results for DNA Sequence 1:</h4>';
            let foundMarkers = false;

            for (const marker of diseaseMarkers) {
                try {
                    const response = await fetch('/perform_kmp', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            dnaChoice: 'seq1', 
                            pattern: marker.sequence
                        })
                    });
                    const result = await response.json();

                    if (result.success && result.matches.length > 0) {
                        foundMarkers = true;
                        const riskClass = `risk-${marker.risk.toLowerCase()}`;
                        resultsHtml += `
                            <div class="p-3 rounded-lg mb-2 ${riskClass}">
                                <p><strong>${marker.name}</strong></p>
                                <p>Pattern: <code>${marker.sequence}</code></p>
                                <p>Risk Level: <span class="font-bold">${marker.risk}</span></p>
                                <p>Found at indices: ${result.matches.join(', ')}</p>
                            </div>
                        `;
                    }
                } catch (error) {
                    console.error(`Error scanning for marker ${marker.name}:`, error);
                    
                }
            }

            if (!foundMarkers) {
                resultsHtml += '<p class="text-gray-600">No predefined disease markers found in DNA Sequence 1.</p>';
            }
            diseaseScanResults.innerHTML = resultsHtml;
            toggleSpinner(diseaseSpinner, false);
        });

       
        navItems.forEach(item => {
            item.addEventListener('click', (event) => {
                event.preventDefault(); 
                const targetSectionId = event.currentTarget.dataset.section;
                showSection(targetSectionId);
            });
        });

        
        getStartedBtn.addEventListener('click', () => {
            showSection('dashboard-section'); 
        });

        
        document.addEventListener('keydown', (event) => {
            if (event.key === 'ArrowRight') {
                event.preventDefault(); 
                currentSectionIndex = (currentSectionIndex + 1) % allSections.length;
                showSection(allSections[currentSectionIndex]);
            } else if (event.key === 'ArrowLeft') {
                event.preventDefault(); 
                currentSectionIndex = (currentSectionIndex - 1 + allSections.length) % allSections.length;
                showSection(allSections[currentSectionIndex]);
            }
        });


        
        document.addEventListener('DOMContentLoaded', () => {
            
            showSection('welcome-section'); 
            updateDashboard('dna', { seq1Length: 'N/A', seq2Length: 'N/A' });
            updateDashboard('kmp', { pattern: 'N/A', matchesCount: 'N/A' });
            updateDashboard('nw', { score: 'N/A', similarity: 'N/A' });
        });



        document.querySelector('.background-video').addEventListener('error', (e) => {
            console.error('Video failed to load:', e);
            document.querySelector('.video-overlay').style.backgroundColor = '#1a202c'; 
 });