# BioSync/kmp_matcher.py

def compute_lps_array(pattern):
    """
    Computes the Longest Proper Prefix Suffix (LPS) array for the KMP algorithm.
    The LPS array stores the length of the longest proper prefix of the pattern
    that is also a suffix of the pattern[0...i].
    """
    m = len(pattern)
    lps = [0] * m
    length = 0  # Length of the previous longest prefix suffix
    i = 1

    while i < m:
        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            i += 1
        else:
            if length != 0:
                length = lps[length - 1]
            else:
                lps[i] = 0
                i += 1
    return lps

def kmp_search(text, pattern):
    """
    Implements the Knuth-Morris-Pratt (KMP) algorithm to find all occurrences
    of a pattern within a text.
    Returns a list of starting indices where the pattern is found.
    """
    n = len(text)
    m = len(pattern)

    if m == 0:
        print("Warning: Pattern is empty.")
        return []
    if n == 0:
        print("Warning: Text is empty.")
        return []
    if m > n:
        print("Warning: Pattern is longer than text, no match possible.")
        return []

    lps = compute_lps_array(pattern)
    matches = []
    i = 0  # index for text
    j = 0  # index for pattern

    while i < n:
        if pattern[j] == text[i]:
            i += 1
            j += 1

        if j == m:
            # Pattern found at index (i - j)
            matches.append(i - j)
            j = lps[j - 1] # Move to the next possible match in pattern
        elif i < n and pattern[j] != text[i]:
            # Mismatch after j matches
            if j != 0:
                j = lps[j - 1] # Do not match lps[0..lps[j-1]-1] characters,
                               # they will match anyway
            else:
                i += 1 # If j is 0, no prefix matches, just move to next character in text
    return matches

# Example usage (for testing this module directly, if needed)
if __name__ == "__main__":
    text = "ABABDABACDABABCABAB"
    pattern = "ABABCABAB"
    print(f"Text: {text}, Pattern: {pattern}")
    print("Matches:", kmp_search(text, pattern)) # Expected: [10]

    text2 = "AAAAAA"
    pattern2 = "AA"
    print(f"Text: {text2}, Pattern: {pattern2}")
    print("Matches:", kmp_search(text2, pattern2)) # Expected: [0, 1, 2, 3, 4]