

def needleman_wunsch_align(seq1, seq2, match_score=2, mismatch_penalty=-1, gap_penalty=-2):
    """
    Performs global sequence alignment using the Needleman-Wunsch algorithm.
    Calculates the optimal alignment score and reconstructs one optimal alignment.

    Args:
        seq1 (str): The first DNA sequence.
        seq2 (str): The second DNA sequence.
        match_score (int): Score for a matching base.
        mismatch_penalty (int): Penalty for a mismatching base.
        gap_penalty (int): Penalty for a gap (insertion or deletion).

    Returns:
        tuple: (alignment_score, aligned_seq1, aligned_seq2, alignment_path_score_matrix)
    """
    n = len(seq1)
    m = len(seq2)

    # Initialize scoring matrix (F) and traceback matrix (P)
    # F[i][j] stores the maximum score for aligning seq1[0...i-1] with seq2[0...j-1]
    # P[i][j] stores the direction from which the optimal score was obtained
    F = [[0] * (m + 1) for _ in range(n + 1)]
    P = [[''] * (m + 1) for _ in range(n + 1)] # 'D': diagonal, 'U': up, 'L': left

    # Initialize first row and column of F and P
    for i in range(n + 1):
        F[i][0] = gap_penalty * i
        if i > 0: P[i][0] = 'U'
    for j in range(m + 1):
        F[0][j] = gap_penalty * j
        if j > 0: P[0][j] = 'L'

    # Fill the scoring matrix and traceback matrix
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            # Score for match/mismatch
            score_diag = F[i-1][j-1] + (match_score if seq1[i-1] == seq2[j-1] else mismatch_penalty)
            # Score for deletion (gap in seq2)
            score_up = F[i-1][j] + gap_penalty
            # Score for insertion (gap in seq1)
            score_left = F[i][j-1] + gap_penalty

            F[i][j] = max(score_diag, score_up, score_left)

            # Store traceback direction
            # Prioritize diagonal (match/mismatch), then up (deletion), then left (insertion)
            if F[i][j] == score_diag:
                P[i][j] = 'D'
            elif F[i][j] == score_up:
                P[i][j] = 'U'
            else: # F[i][j] == score_left
                P[i][j] = 'L'

    # Traceback to reconstruct the alignment
    aligned_seq1 = []
    aligned_seq2 = []
    i, j = n, m

    while i > 0 or j > 0:
        if P[i][j] == 'D':
            aligned_seq1.append(seq1[i-1])
            aligned_seq2.append(seq2[j-1])
            i -= 1
            j -= 1
        elif P[i][j] == 'U':
            aligned_seq1.append(seq1[i-1])
            aligned_seq2.append('-') # Gap in seq2
            i -= 1
        else: # P[i][j] == 'L'
            aligned_seq1.append('-') # Gap in seq1
            aligned_seq2.append(seq2[j-1])
            j -= 1

    # Reverse the sequences as they were built backwards
    return F[n][m], ''.join(aligned_seq1[::-1]), ''.join(aligned_seq2[::-1]), F






if __name__ == "__main__":
    seq1 = "AGACT"
    seq2 = "ATC"
    score, aligned1, aligned2, matrix = needleman_wunsch_align(seq1, seq2)
    print(f"Sequence 1: {seq1}")
    print(f"Sequence 2: {seq2}")
    print(f"Alignment Score: {score}")
    print(f"Aligned Seq1: {aligned1}")
    print(f"Aligned Seq2: {aligned2}")
    print("\nScoring Matrix:")
    for row in matrix:
        print(row)

    print("\n--- Another Example ---")
    seq_a = "GCATGCU"
    seq_b = "GATTACA"
    score_ab, aligned_a, aligned_b, matrix_ab = needleman_wunsch_align(seq_a, seq_b, match_score=1, mismatch_penalty=-1, gap_penalty=-1)
    print(f"Sequence A: {seq_a}")
    print(f"Sequence B: {seq_b}")
    print(f"Alignment Score: {score_ab}")
    print(f"Aligned A: {aligned_a}")
    print(f"Aligned B: {aligned_b}")